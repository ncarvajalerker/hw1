/* Game of Life Natalia Carvajal Erker- life.c
*/


#include <stdio.h>
#include <stdlib.h>
#include "twoD.h"
#include "life.h"

#define BHeight  80 //height of imported board
#define BWidth   30//width of imported board

/** Main function.
 * @param argc Number of words on the command line.
 * @param argv Array of pointers to character strings containing the
 *    words on the command line.
 * @return 0 if success, 1 if invalid command line or unable to open file.
 *
 */
int main(int argc, char **argv) {
	printf("Game of Life\n");

	char *inputFileName; // Name of file containing initial grid
	FILE *input; // Stream descriptor for file containing initial grid
	int rows; // Number of rows in the grid
	int columns; // Number of columns in the grid
	int gens; // Number of generations to produce
	int doPrint; // 1 if user wants to print each generation, 0 if not
	int doPause; // 1 if user wants to pause after each generation, 0 if not
	int **gridA; // A 2D array to hold the pattern

	// See if there are the right number of arguments on the command line
	if ((argc < 5) || (argc > 7)) {
		// If not, tell the user what to enter.
		printf("Usage:\n");
		printf("  ./life rows columns generations inputFile [print] [pause]\n");
		return EXIT_FAILURE;
	}

	/* Save the command-line arguments.
	   Also need to check if print and/or pause arguments were entered,
	   and if so, what they were.
	   A switch statement might be handy here.
	*/
	rows = atoi(argv[1]); // Convert from character string to integer.
	columns = atoi(argv[2]);
	gens = atoi(argv[3]);
	inputFileName = argv[4];


	/* Here is how you would allocate an array to hold the grid.
	*/
	gridA = make2Dint(rows, columns);
	// You should check that it succeeded.


	/* Eventually, need to try to open the input file.
	*/
	input = fopen(inputFileName, "r");
	if (!input) {
		printf("Unable to open input file: %s\n", inputFileName);
		return EXIT_FAILURE;
	}

	/*Once opened, you can read from the file one character at a time with fgetc().
	 * You can read one line at a time using fgets().
	 * You can read from standard input (the keyboard) with getchar().
	*/
	/*char* abcd =  (char*) malloc(100 * sizeof(char));
	char* abc = fgets(abcd, 100, input);
	oneLineToGrid(abcd, gridA, 0, columns);*/ //test for printing input file

	parseFile(input, gridA, rows, columns); //this will call the file input with GridA which is the blinker test

	for (int i = 0; i < rows; i++){ //i gets assigned to each value for the row and assign iterate through the file
		for( int j = 0; j < columns; j++){ //j gets assigned to each value in the column to iterate through the file
			printf("%d",  gridA[i][j]); //will take the first value in the file and assign it to the 2D array
		}
		printf("\n"); //needs to skip a line so that it has rows and columns
	} //this loop



	return EXIT_SUCCESS;

}

void initialBoard(int board[][BHeight]){
	int i, j;
	for (i=0; i<BWidth; i++){
		for(j=0; j<BHeight; j++){
			board[i][j]= 0;
		}
	}
}

int xadd (int i, int e){ // goes through the values of width to check all the values in the array and apply them to the play function
	i += e;
	while(i < 0){
		i += BWidth; //go through the column
	}
	while(i >= BWidth){
		i -= BWidth; //when starting a new column need to negate the values
	}
	return i;
}

int yadd (int i, int e){ // goes through the values of height to check all the values in the array and apply them to the play function
	i += e;
	while(i < 0){
			i += BHeight; //go through the row
		}
		while(i >= BHeight){
			i -= BHeight; //when starting a new row have to negate the values
		}
		return i;
}


int adjBoard (int board[][BHeight], int i, int j){ // goes through the board adjacently
	 	int n, m;
	 	int count = 0; //count used to initialize to 0 and start at the beginning
	 	for(n = -1; n<=1; n++){
	 		for (m=-1; m<=1; m++){
	 			if(n || 1){
	 				if (board[xadd(i,n)][yadd(j,m)]){
	 					count++; //changes each character in the board

	 			}

	 		}
	 	}

	 	}
	return count; //returns the count to then go back and restart the loop for the amount of times needed
}



void play (int board [][BHeight]){ //this function will have the 3 instances of the game
	int i, j, e, newboard[BWidth][BHeight];
	for(i = 0; i <BWidth; i++){
		for (j = 0; j< BHeight; j++){
			e = adjBoard (board, i, j); //position the boards checking
			if (e == 2) newboard[i][j] = board[i][j]; //dead case in the game
			if (e == 3) newboard[i][j] = 1; //new life case in the game
			if (e < 2) newboard[i][j] = 0; //survival case in the game
			if (e > 3) newboard[i][j] = 0; //survival case in the game
		}

		for (i = 0; i < BWidth; i++){
			for (j = 0; j< BHeight; j++){
				board[i][j] = newboard[i][j]; //makes the new board and then will go back and iterate it through the cases
			}
		}
	}

}


void print (int board[][BHeight]){
	int i, j; // goes through each row

	for (i = 0; i <BHeight; i++){ //prints the col pos
		for( j = 0; j< BWidth; j++){
			printf("%c", board [j][i] ? 'x' : ' '); //returns what goes inside the spot
		}
		printf("\n"); //skip a line for formatting
	}

}



int** oneLineToGrid (char *line, int **board, int r, int c){
	int col = 0; //inicilize column to zero so it starts at the beginning of the array
	char str = line [0]; //set strings equal to the array line
	for (int i = 0; str != '\0'; i++){ //if string doesn't equals null continue iterating
				if (str == 'x'){ //if string is x in the fine, put a 1 in the array
					board[r][col] = 1;
				}
				else{
					board[r][col] = 0; //if the string is o (not x) set it equal to 0
				}
				col++;
				str = line[i+1]; //go through and make an array by increasing the storing value by 1
		if(col == c){ //if the column is equal to c then break
			break;
		}
	}
	if(col+1 < c){ //if the column is greater than c
		for(int i = col; i < c; i++){
			board[r][i] = 0;
		}
	}
	return board; //returns the board that will then get printed out in main
}

void parseFile (FILE *f, int **board, int r, int c){ //takes in the file, the board to assign it to, and two integers for column and row
		char line [1000]; //random value assigned to character length so it runs
		fgets(line, sizeof(line), f); //fget string goes through the strings in the file and gets their numerical value
		for (int i = 0; i < r; i++){ //i iterates through the rows
			if (oneLineToGrid(line, board, i, c) == NULL){ //if there is no value in the file the program will break
				break;
			}
			fgets(line, sizeof(line), f); //will get the numerical value of the string
		}
}




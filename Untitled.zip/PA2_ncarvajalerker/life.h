/*
 * life.h
 *
 *  Created on: Jan 28, 2018
 *      Author: ncarvajalerker
 */

#ifndef LIFE_H_
#define LIFE_H_

int** oneLineToGrid (char *line, int **board, int r, int c);

void parseFile (FILE *f, int **board, int r, int c);

#endif /* LIFE_H_ */
